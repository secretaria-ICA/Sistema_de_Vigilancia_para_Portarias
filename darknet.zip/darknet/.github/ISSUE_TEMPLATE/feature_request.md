---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: Feature-request
assignees: ''

---

For Feature-request:
    * describe your feature as detailed as possible
    * provide link to the paper and/or source code if it exist
    * attach chart/table with comparison that shows improvement
